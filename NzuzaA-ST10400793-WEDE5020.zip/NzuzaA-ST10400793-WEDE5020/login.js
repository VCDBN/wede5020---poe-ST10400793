//create 2 variables

let output = document.getElementById("outputText");
let btn = document.getElementById("btn");


//create a variable that holds a number
//make use of the math.random method
//make use of the math.floor method
//each time the page loads the browser assigns a number


let number = [Math.floor(Math.random()*100)]   


//using an event listener
//handles an element
//takes users input


btn.addEventListener('click',function(){
    let input = document.getElementById("userInput").value ;

    if (input==number){
        output.innerHTML='Guess correct, ${number}'
    }
    else if (input > number){
        output.innerHTML = "Guess is too High"
    }
    if (input < number){
        output.innerHTML = "Guess is too low"
    }
});